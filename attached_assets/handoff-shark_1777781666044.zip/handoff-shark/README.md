# Pacote de paridade — BetShark Pro × FreeBet PRO

Esta pasta contém **4 documentos** que descrevem o que falta no modal "Novo Procedimento" do lado do BetShark Pro pra ficar idêntico ao do FreeBet PRO. O contrato HTTP entre as duas plataformas (`POST /api/integracoes/betshark/procedimentos` e variantes) já está homologado — esses docs são sobre **paridade da experiência de cadastro** e da tela de acompanhamento.

A integração já aceita os campos vistos hoje no payload do Shark; o normalizador de aliases (`normalizeBetsharkAliases` em `server/routes/integracoesBetshark.ts:253`) converte os 4 nomes alternativos do Shark pros nomes canônicos antes da validação Zod. Nada precisa mudar lá.

---

## Ordem de leitura sugerida

1. **[01 — Comparativo de campos do modal](./01-comparativo-campos-modal.md)** ⭐ **inclui prints lado a lado**
   Tabela campo a campo do nosso modal (Painel de Envios → Novo Procedimento) marcando o que o Shark **já manda** vs **falta mandar**, com tipo, exemplo e obrigatoriedade. **Seção §0 nova:** comparação visual dos modais Ganhar/Queimar lado a lado, com 2 gaps gritantes destacados (autocomplete de evento + autocomplete de origem da FB).

2. **[02 — Guia API-Football passo a passo](./02-guia-api-football.md)**
   Como o autocomplete de eventos com `fixture_id` funciona no nosso lado e como o Shark replica do zero: pegar token na api-sports.io, headers, endpoint, parâmetros, resposta normalizada, debounce, cache. Habilita as funcionalidades secundárias (badge AO VIVO, opt-in 🔔 de 2 gols de vantagem, filtro de jogo encerrado).

3. **[03 — Lógica Ganhar FreeBet / Queimar FreeBet](./03-logica-ganhar-queimar-fb.md)** ⭐ **inclui spec do autocomplete de Origem FB**
   Quando o procedimento é `GANHAR_FB` (gera FB futura) vs `QUEIMAR_FB` (gasta FB já ganha) vs `NORMAL`. Documenta o `deduzirTipoFB()` (servidor força o tipo correto mesmo se o checkbox manual estiver errado), a cadeia via `external_referencia_id`, e — **§3 novo** — a spec completa do autocomplete "Vincular Freebet Origem" com endpoint, payload da lista, UX, validação e edge cases. Sem isso, o ciclo da FB não fecha.

4. **[04 — Aba "FreeBets Ganhas"](./04-aba-freebets-ganhas.md)**
   Replica conceitual da nossa tela: 3 status derivados (`falta_girar`, `queimando`, `concluida`), 4 KPIs, filtros pills (período × status), comportamento "ciclo completo" (quando a queima fecha automaticamente a origem). Sugere endpoint equivalente no lado do Shark.

5. **[05 — Lista de Procedimentos (13 colunas)](./05-lista-procedimentos.md)** 🆕
   Tabela "Lista de Procedimentos" do FreeBet PRO espelhada para o Shark. Documenta as **13 colunas fixas** (DATA CRIAÇÃO, Nº, PLATAFORMA, PROMOÇÃO, EVENTO, CATEGORIA, STATUS, REF. FB, GANHAR FREEBET, L/P, TAGS, LINK, AÇÕES), os 8 status derivados client-side, ordenação, filtros, toggle Lista ↔ FreeBets Ganhas, e — **§2.5** — os 2 botões inline ⏳ **Tachar** + ↻ **Reenviar** ao lado do pill de status, com efeito propagado para a página Procedimentos PRO do cliente (badge `Passou`, badge piscante `Reenviado — revise`).

6. **[06 — Modal "Definir Resultados"](./06-modal-definir-resultados.md)** 🆕
   Modal que aparece ao clicar no botão "Definir resultado" da coluna AÇÕES. Documenta os **3 blocos coexistentes** (A: Lucro/Prejuízo, B: Ganhar Freebet, Duplo Green) + Observação, validação, payload do PATCH, comportamento pós-save (FALTA_GIRAR_FB, cascade FB com toast Desfazer, FreeBets Ganhas), e a regra do gatilho `temNumeroCadastrado()`. **§7.3:** alinhamento honesto sobre o vínculo da FB origem — onde aparece e onde NÃO aparece.

---

## Recados pro time do Shark

- **A integração POST/PATCH já tá funcionando.** O smoke test do dia 03/05 passou com Status 201, procedimento id=35 numero=500. Esses **6 documentos** são sobre **a UI de cadastro**, a **tela de acompanhamento** e o **modal de resultado** do lado de vocês.
- **A chave da API-Football vai ser fornecida pelo time FreeBet.** Detalhes em `02-guia-api-football.md`. Não compartilhem a chave em commit/log; usem env var.
- **Cada documento termina com checklist objetiva** — usem como controle interno de "feito / em andamento / não começou".
- **Prints reais do FreeBet PRO + Shark estão em `prints/`** — comparação lado a lado dos modais Ganhar/Queimar, da Lista de Procedimentos, do modal Definir Resultados, e dos botões inline Tachar/Reenviar.
- Qualquer dúvida, abram issue mencionando o número da seção (ex: "doc 03 §3.2") pra ficar fácil rastrear.

---

## Resumo dos gaps bloqueantes (priorizar nesta ordem)

1. **Autocomplete "Vincular Freebet Origem"** no modo Queimar (doc 01 §0.2 + doc 03 §3) — substitui o campo texto livre "Referência Freebet" do Shark. Sem ele, o ciclo da FB depende do usuário decorar nº de procedimento → causa `422 UNRESOLVED_REFERENCE` e quebra a aba FreeBets Ganhas.
2. **Autocomplete de Evento/Partida com `fixture_id`** (doc 01 §0.1 + doc 02) — substitui o texto livre "Descrição (Time x Time)". Habilita opt-in 🔔, badge AO VIVO, filtro de jogo encerrado.
3. **Botões inline ⏳ Tachar + ↻ Reenviar na coluna STATUS** (doc 05 §2.5) — ações de admin mais usadas no dia a dia, com efeito visual imediato no Procedimentos PRO do cliente.
4. **Modal Definir Resultados com 3 blocos coexistentes** (doc 06) — substitui qualquer modal/form simplificado de "marcar resultado".
