# 02 — Guia API-Football passo a passo

> **Objetivo:** Ensinar o time do Shark a implementar, do zero, o autocomplete de eventos com `fixture_id` no modal "Novo Procedimento" de vocês — exatamente como funciona no nosso `EventoAutocomplete.jsx`. Sem precisar olhar código nosso.

---

## 1. O que muda na UX

Hoje o modal de vocês tem (provavelmente) um campo de texto livre pra "Partida". Com este guia, vocês adicionam:

- Dropdown que abre conforme o usuário digita 2+ caracteres.
- Lista de jogos reais do dia (ou amanhã/depois) puxada da API-Football.
- Ao clicar em um jogo, captura `fixture_id` (inteiro), `kickoff_at` (UTC ISO 8601), nome do campeonato e país.
- Mantém possibilidade de digitar livre (caso o jogo não esteja na lista).
- Mostra um badge "AO VIVO" pros jogos que já começaram.

**Por que vocês querem isso:** o `fixture_id` desbloqueia 3 features no FreeBet PRO sem custo adicional pra vocês:
- 🔔 Opt-in de "2 gols de vantagem" — alerta Telegram automático.
- ⚡ Badge "AO VIVO" / "ENCERRADO" no card do procedimento.
- 🔁 Filtro automático de jogos encerrados sem resultado registrado.

---

## 2. Pegando a chave da API-Football

A FreeBet **vai fornecer a chave** pro time do Shark — não precisam criar conta. Mas pra entenderem o que estão usando:

1. A API é a [api-sports.io](https://api-sports.io/documentation/football/v3) (também espelhada no RapidAPI).
2. Plano necessário: **Pro** (≈ US$ 19/mês) — 7.500 chamadas/dia, jogos em tempo real, ligas brasileiras incluídas.
3. Host base: `v3.football.api-sports.io` (versão direta) ou `api-football-v1.p.rapidapi.com` (RapidAPI).
4. Header de autenticação:
   - **Direto (api-sports.io):** `x-apisports-key: <SUA_CHAVE>`
   - **Via RapidAPI:** `x-rapidapi-key: <SUA_CHAVE>` + `x-rapidapi-host: v3.football.api-sports.io`

> ⚠ **Nunca commitem a chave.** Usem env var (ex: `API_FOOTBALL_KEY`). Nunca exponham no frontend — todas as chamadas devem sair do backend de vocês, com o frontend chamando um endpoint próprio (`GET /api/eventos/buscar?q=...`).

---

## 3. Endpoint usado: `GET /fixtures`

### 3.1 Parâmetros que o FreeBet usa hoje

```
GET https://v3.football.api-sports.io/fixtures?date=YYYY-MM-DD
Headers:
  x-apisports-key: <chave>
```

- `date=YYYY-MM-DD` — pega todos os jogos do dia (UTC). O FreeBet faz **3 chamadas em paralelo**: hoje, amanhã, depois de amanhã (`API_FOOTBALL_DIAS_AHEAD = 3`).
- Não usamos `live=all` no `/fixtures` por dia — o flag "AO VIVO" é derivado no cliente comparando `kickoff_at` com `Date.now()` (jogo é "ao vivo" se já começou e estamos na janela de 4h pós-kickoff).

### 3.2 Resposta crua (resumo dos campos relevantes)

```json
{
  "response": [
    {
      "fixture": {
        "id": 1234567,
        "date": "2026-05-10T19:00:00+00:00",
        "status": { "short": "NS", "long": "Not Started" }
      },
      "league": {
        "name": "Brasileirão Serie A",
        "country": "Brazil"
      },
      "teams": {
        "home": { "name": "Flamengo" },
        "away": { "name": "Palmeiras" }
      },
      "goals": { "home": null, "away": null }
    }
  ]
}
```

### 3.3 Normalização (forma que o frontend espera)

O nosso backend transforma cada `response[i]` no objeto abaixo (mais simples e direto):

```json
{
  "nome": "Flamengo x Palmeiras",
  "campeonato": "Brasileirão Serie A (Brazil)",
  "data_hora": "2026-05-10T19:00:00.000Z",
  "fixture_id": 1234567,
  "kickoff_at": "2026-05-10T19:00:00.000Z",
  "esporte": "futebol",
  "source": "api-football"
}
```

Use exatamente esse formato no endpoint do backend de vocês — torna o frontend trivial de implementar.

---

## 4. Cache e quota

A API-Football permite **7.500 calls/dia no plano Pro**. Sem cache, vocês esgotam em horas. Estratégia que usamos:

- **Cache em memória de 12 horas** (chave: `fetchedAt + lista`).
- Cada refresh executa 3 chamadas (hoje + 2 dias).
- Total: ~6 chamadas/dia (12h ÷ 2 atualizações × 3 dias). Sobra cota de sobra.

```js
// Pseudocódigo (Node)
let cache = { data: [], fetchedAt: 0 };
const TTL = 12 * 60 * 60 * 1000;
const DIAS_AHEAD = 3;

async function fetchFixtures() {
  if (Date.now() - cache.fetchedAt < TTL && cache.data.length > 0) {
    return cache.data;
  }
  const todas = [];
  for (let i = 0; i < DIAS_AHEAD; i++) {
    const d = new Date(Date.now() + i * 86400_000);
    const ymd = d.toISOString().slice(0, 10);
    const r = await fetch(`https://v3.football.api-sports.io/fixtures?date=${ymd}`, {
      headers: { 'x-apisports-key': process.env.API_FOOTBALL_KEY }
    });
    if (!r.ok) continue;
    const json = await r.json();
    for (const f of (json.response || [])) {
      const home = f?.teams?.home?.name;
      const away = f?.teams?.away?.name;
      const fxId = Number(f?.fixture?.id);
      const dt = f?.fixture?.date;
      if (!home || !away || !Number.isFinite(fxId) || !dt) continue;
      todas.push({
        nome: `${home} x ${away}`,
        campeonato: `${f.league?.name || ''}${f.league?.country ? ` (${f.league.country})` : ''}`,
        data_hora: new Date(dt).toISOString(),
        fixture_id: fxId,
        kickoff_at: new Date(dt).toISOString(),
        esporte: 'futebol',
        source: 'api-football',
      });
    }
  }
  cache = { data: todas, fetchedAt: Date.now() };
  return todas;
}
```

---

## 5. Endpoint de busca (backend de vocês)

Crie um endpoint próprio, autenticado, que filtra a lista cacheada pelo termo de busca:

```js
// GET /api/eventos/buscar?q=flam
app.get('/api/eventos/buscar', requireAuth, async (req, res) => {
  const q = String(req.query.q || '').trim().toLowerCase();
  if (q.length < 2) return res.json([]);

  const todas = await fetchFixtures();
  const agora = Date.now();
  const JANELA_AO_VIVO = 4 * 60 * 60 * 1000; // 4h pós-kickoff = ainda relevante

  const resultado = todas
    .filter(f => f.nome.toLowerCase().includes(q))
    .filter(f => new Date(f.data_hora).getTime() > agora - JANELA_AO_VIVO)
    .sort((a, b) => new Date(a.data_hora) - new Date(b.data_hora))
    .slice(0, 15);

  res.json(resultado);
});
```

---

## 6. Frontend (autocomplete)

Pontos críticos pra UX boa:

- **Debounce 250ms** — não dispara request a cada tecla.
- **AbortController** — cancela request anterior se o usuário continuar digitando.
- **Mínimo 2 caracteres** — abaixo disso a lista é vazia.
- **Limpar seleção se o texto muda** — se o usuário selecionou "Flamengo x Palmeiras" e depois apaga "Palmeiras", o `fixture_id` deve voltar pra `null`.
- **Auto-vincular ao reabrir** — em modo edição, se o texto bate exato com um jogo da lista, auto-vincula o `fixture_id` (busca por nome + match exato case-insensitive).

Esqueleto React (vanilla JS é equivalente):

```jsx
function EventoAutocomplete({ value, onChange, onSelectSugestao }) {
  const [sugestoes, setSugestoes] = useState([]);
  const debounceRef = useRef(null);
  const abortRef = useRef(null);

  function buscar(termo) {
    if (debounceRef.current) clearTimeout(debounceRef.current);
    if (!termo || termo.length < 2) return setSugestoes([]);
    debounceRef.current = setTimeout(async () => {
      if (abortRef.current) abortRef.current.abort();
      abortRef.current = new AbortController();
      const r = await fetch(`/api/eventos/buscar?q=${encodeURIComponent(termo)}`, {
        signal: abortRef.current.signal,
        credentials: 'include',
      });
      if (r.ok) setSugestoes(await r.json());
    }, 250);
  }

  function selecionar(s) {
    onChange(s.nome);
    onSelectSugestao({
      partida_descricao: s.nome,
      fixture_id: s.fixture_id,
      kickoff_at: s.kickoff_at,
    });
    setSugestoes([]);
  }

  return (
    <div>
      <input
        value={value}
        onChange={e => { onChange(e.target.value); buscar(e.target.value); }}
        placeholder="Ex: Flamengo x Palmeiras"
      />
      {sugestoes.map(s => (
        <div key={s.fixture_id} onClick={() => selecionar(s)}>
          {s.nome} — {s.campeonato}
        </div>
      ))}
    </div>
  );
}
```

---

## 7. Mandando pro FreeBet PRO

Quando o usuário salvar o procedimento, **incluir os 2 campos novos** no `POST /api/integracoes/betshark/procedimentos`:

```json
{
  "external_id": "bsk:abc-123",
  "titulo": "...",
  "casa_aposta": "Bet365",
  "partida_descricao": "Flamengo x Palmeiras",
  "fixture_id": 1234567,                       // ← NOVO
  "kickoff_at": "2026-05-10T19:00:00.000Z",    // ← NOVO
  "data_partida": "2026-05-10",
  "horario_partida": "16:00",
  ...resto do payload
}
```

`fixture_id` e `kickoff_at` já são aceitos pelo schema do FreeBet sem mudança nenhuma.

---

## 8. Checklist de implementação (Shark)

- [ ] Cadastrar `API_FOOTBALL_KEY` como env var no backend.
- [ ] Implementar `fetchFixtures()` com cache de 12h e 3 dias de horizonte.
- [ ] Expor `GET /api/eventos/buscar?q=...` no backend.
- [ ] Criar `EventoAutocomplete` no frontend com debounce 250ms + AbortController.
- [ ] Capturar `fixture_id` e `kickoff_at` quando o usuário selecionar uma sugestão.
- [ ] Limpar `fixture_id`/`kickoff_at` quando o usuário editar manualmente o texto da partida.
- [ ] Incluir os 2 novos campos no payload do POST/PATCH pro FreeBet.
- [ ] Testar: criar procedimento via autocomplete, conferir no FreeBet PRO se o badge AO VIVO aparece quando o jogo começa.

---

## 9. Próximo doc

**[03 — Lógica Ganhar FreeBet / Queimar FreeBet](./03-logica-ganhar-queimar-fb.md)**
